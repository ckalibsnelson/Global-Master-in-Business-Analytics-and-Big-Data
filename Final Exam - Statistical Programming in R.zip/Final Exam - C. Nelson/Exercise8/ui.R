library(shiny);
library(ggplot2);
library(data.table);

shinyUI(fluidPage(
    titlePanel("Final Quiz: Exercise 8"),
    sidebarPanel(selectInput(inputId = "cut", 
                             multiple = TRUE,
                             label = "Select the type of cut", 
                             choices = unique(diamonds$cut))), 
    mainPanel(plotOutput("boxPlot"))
    )
)