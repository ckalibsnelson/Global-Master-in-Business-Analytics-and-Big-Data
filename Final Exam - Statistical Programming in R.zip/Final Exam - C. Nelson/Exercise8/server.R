library(shiny)
library(dplyr)

shinyServer(function(input, output) {
    selected_cut <- reactive({
      req(input$cut)
      diamonds %>% 
        filter(
          cut == input$cut
        )
    })
    
    output$boxPlot <- renderPlot({
        ggplot(selected_cut(), aes(x = selected_cut()$cut, y = selected_cut()$price)) + 
            geom_boxplot(aes()) +
            scale_y_continuous(trans = "reverse") + 
            ggtitle("From diamonds dataset") +  
            theme(aspect.ratio = 1) +
            labs(x = "Cut", y = "Price");
    })

})
